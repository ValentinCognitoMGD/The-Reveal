Just a simple mod by Valentin Cognito. Don't look at the files before playing, you'll just spoil the surprise!

To access the mod's contents, visit Lillian. You'll see a new talk option. Note that this requires having progressed your relationship with Lillian far enough, i.e. to the stage where you've gotten Demon Layer from her.

I hope you'll like it! Don't take it too seriously, though ^^'

With thanks to Kaa for troubleshooting!


Note: if you overwrote your save while in the fight (you'll know which one I mean), you can Super Surrender to get out of it.


Music Credits:
- "Numina" is by Peritune
- "Phoenix Wright Ace Attorney OST Pressing Pursuit Cornered Variation" is from Ace Attorney, developed by Capcom